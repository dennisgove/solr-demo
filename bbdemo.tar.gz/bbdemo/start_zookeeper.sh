#!/bin/bash

echo "Starting Zookeeper"
echo "=================="

bin/zookeeper/bin/zkServer.sh start
