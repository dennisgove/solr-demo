#!/bin/bash

echo "Stopping Zookeeper"
echo "=================="

bin/zookeeper/bin/zkServer.sh stop
