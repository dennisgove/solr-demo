#!/bin/bash

echo "Starting Solr"
echo "============="

bin/solr/bin/solr -cloud -z localhost:2181 -s data/solr/home
